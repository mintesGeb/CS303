function load() {
	let id = document.getElementById("result");
	id.innerHTML = "Lab W3D5";
}