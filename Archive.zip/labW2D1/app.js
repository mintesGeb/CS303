function load() {
	let id = document.getElementById("result");
	id.innerHTML = "Lab W2D1";
}