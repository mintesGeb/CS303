function load() {
	let id = document.getElementById("result");
	id.innerHTML = "Lab W1D2";
}